public class Testador {
    public static void main(String[] args) throws Exception{
        Produto p1 = new Produto("Teclado Mecânico", 349.9, 15);
        System.out.println(GeradorJson.serializar(p1));

        Usuario u = new Usuario("joselito", "jose@gmail.com", true);
        System.out.println(GeradorJson.serializar(u));
        
    }
}
